import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { EventTypes } from './components/EventTypes';
import { Specifications } from './components/Specifications';
import { Equipment } from './components/Equipment';
import { Gallery } from './components/Gallery';
import { Pricing } from './components/Pricing';
import { AdditionalServices } from './components/AdditionalServices';
import { Testimonials } from './components/Testimonials';
import { FAQ } from './components/FAQ';
import { BookingForm } from './components/BookingForm';
import { Footer } from './components/Footer';

export default function App() {
  return (
    <div className="size-full">
      <Header />
      <main id="hero">
        <Hero />
        <EventTypes />
        <Features />
        <Specifications />
        <Equipment />
        <Gallery />
        <Pricing />
        <AdditionalServices />
        <Testimonials />
        <FAQ />
        <BookingForm />
      </main>
      <Footer />
    </div>
  );
}