import { Utensils, Camera, Users2, FileText, Car, Shirt } from 'lucide-react';

const services = [
  {
    icon: Utensils,
    title: 'Организация питания',
    description: 'Кофе-брейки, обеды, фуршеты от проверенных партнеров',
    price: 'от 500 ₽/чел'
  },
  {
    icon: Camera,
    title: 'Фото и видеосъемка',
    description: 'Профессиональная съемка вашего мероприятия',
    price: 'от 5 000 ₽'
  },
  {
    icon: Users2,
    title: 'Модератор/ведущий',
    description: 'Опытный модератор для вашего мероприятия',
    price: 'от 8 000 ₽'
  },
  {
    icon: FileText,
    title: 'Печать материалов',
    description: 'Раздаточные материалы, сертификаты, программы',
    price: 'от 10 ₽/лист'
  },
  {
    icon: Car,
    title: 'Трансфер',
    description: 'Организация транспорта для участников',
    price: 'по запросу'
  },
  {
    icon: Shirt,
    title: 'Брендирование',
    description: 'Оформление зала в фирменном стиле компании',
    price: 'от 3 000 ₽'
  }
];

export function AdditionalServices() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#f97350' }}>
            <span className="text-white">Дополнительно</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Дополнительные услуги
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Мы позаботимся обо всем, чтобы ваше мероприятие прошло идеально
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <div
                key={index}
                className="bg-white rounded-2xl p-6 shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      backgroundColor: index % 2 === 0 ? '#f9735020' : '#24937a20'
                    }}
                  >
                    <Icon
                      className="w-7 h-7"
                      style={{ color: index % 2 === 0 ? '#f97350' : '#24937a' }}
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl mb-2">{service.title}</h3>
                    <p className="text-gray-600 mb-3 text-sm">{service.description}</p>
                    <div
                      className="inline-block px-3 py-1 rounded-full text-sm"
                      style={{
                        backgroundColor: index % 2 === 0 ? '#f9735015' : '#24937a15',
                        color: index % 2 === 0 ? '#f97350' : '#24937a'
                      }}
                    >
                      {service.price}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Contact Note */}
        <div className="mt-12 bg-white rounded-2xl p-8 shadow-lg max-w-3xl mx-auto text-center">
          <h3 className="text-2xl mb-4">Нужна помощь в организации?</h3>
          <p className="text-gray-600 mb-6">
            Наши менеджеры помогут подобрать оптимальный набор услуг и рассчитают итоговую стоимость
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+74951234567"
              className="px-6 py-3 rounded-lg text-white transition-all duration-300 hover:shadow-lg"
              style={{ backgroundColor: '#24937a' }}
            >
              Позвонить менеджеру
            </a>
            <button
              onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-6 py-3 rounded-lg border-2 transition-all duration-300 hover:shadow-lg"
              style={{
                borderColor: '#f97350',
                color: '#f97350'
              }}
            >
              Оставить заявку
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
