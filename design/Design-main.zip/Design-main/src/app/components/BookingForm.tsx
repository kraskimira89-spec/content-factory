import { useState } from 'react';
import { Calendar, Clock, Users, Mail, Phone, User, Send } from 'lucide-react';

export function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    time: '',
    duration: '',
    guests: '',
    message: ''
  });

  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // В реальном приложении здесь была бы отправка данных на сервер
    console.log('Booking data:', formData);
    setSubmitted(true);
    setTimeout(() => setSubmitted(false), 5000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <section id="booking" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#f97350' }}>
            <span className="text-white">Бронирование</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Забронируйте конференц-зал
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Заполните форму, и мы свяжемся с вами в течение 30 минут
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {submitted && (
            <div className="mb-8 p-6 bg-green-50 border-2 border-green-500 rounded-xl">
              <p className="text-green-800 text-center">
                ✓ Спасибо за заявку! Мы свяжемся с вами в ближайшее время.
              </p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="bg-gray-50 rounded-2xl p-8 shadow-lg">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              {/* Name */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <User className="inline w-5 h-5 mr-2" />
                  Ваше имя *
                </label>
                <input
                  type="text"
                  name="name"
                  required
                  value={formData.name}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                  placeholder="Иван Иванов"
                />
              </div>

              {/* Email */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Mail className="inline w-5 h-5 mr-2" />
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                  placeholder="example@mail.com"
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Phone className="inline w-5 h-5 mr-2" />
                  Телефон *
                </label>
                <input
                  type="tel"
                  name="phone"
                  required
                  value={formData.phone}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                  placeholder="+7 (999) 123-45-67"
                />
              </div>

              {/* Date */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Calendar className="inline w-5 h-5 mr-2" />
                  Дата *
                </label>
                <input
                  type="date"
                  name="date"
                  required
                  value={formData.date}
                  onChange={handleChange}
                  min={new Date().toISOString().split('T')[0]}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                />
              </div>

              {/* Time */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Clock className="inline w-5 h-5 mr-2" />
                  Время начала *
                </label>
                <input
                  type="time"
                  name="time"
                  required
                  value={formData.time}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                />
              </div>

              {/* Duration */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Clock className="inline w-5 h-5 mr-2" />
                  Длительность *
                </label>
                <select
                  name="duration"
                  required
                  value={formData.duration}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                >
                  <option value="">Выберите</option>
                  <option value="2">2 часа</option>
                  <option value="4">4 часа</option>
                  <option value="6">6 часов</option>
                  <option value="full">Полный день</option>
                </select>
              </div>

              {/* Guests */}
              <div>
                <label className="block mb-2 text-gray-700">
                  <Users className="inline w-5 h-5 mr-2" />
                  Количество гостей *
                </label>
                <input
                  type="number"
                  name="guests"
                  required
                  min="1"
                  max="50"
                  value={formData.guests}
                  onChange={handleChange}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                  placeholder="10"
                />
              </div>

              {/* Message */}
              <div className="md:col-span-2">
                <label className="block mb-2 text-gray-700">
                  Дополнительные пожелания
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-opacity-50 resize-none"
                  style={{ '--tw-ring-color': '#f97350' } as React.CSSProperties}
                  placeholder="Расскажите нам о особых требованиях к мероприятию..."
                />
              </div>
            </div>

            <button
              type="submit"
              className="w-full py-4 rounded-lg text-white transition-all duration-300 hover:shadow-lg hover:scale-[1.02] flex items-center justify-center gap-2"
              style={{ backgroundColor: '#f97350' }}
            >
              <Send className="w-5 h-5" />
              Отправить заявку
            </button>

            <p className="text-sm text-gray-500 text-center mt-4">
              Нажимая кнопку, вы соглашаетесь с условиями обработки персональных данных
            </p>
          </form>
        </div>
      </div>
    </section>
  );
}
