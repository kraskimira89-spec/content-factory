import { Monitor, Wifi, Video, Mic, Coffee, Printer, Projector, Volume2 } from 'lucide-react';

const equipmentCategories = [
  {
    title: 'Презентационное оборудование',
    color: '#f97350',
    items: [
      { icon: Projector, name: 'Проектор 4K Ultra HD' },
      { icon: Monitor, name: 'Экран 3 метра с электроприводом' },
      { icon: Monitor, name: 'LED-телевизор 75"' },
      { name: 'Флипчарт с маркерами' },
      { name: 'Магнитно-маркерная доска' },
      { name: 'Лазерная указка' }
    ]
  },
  {
    title: 'Звуковое оборудование',
    color: '#24937a',
    items: [
      { icon: Mic, name: '4 беспроводных микрофона' },
      { icon: Volume2, name: 'Акустическая система премиум-класса' },
      { name: 'Микшерный пульт' },
      { name: 'Микрофон-петличка' }
    ]
  },
  {
    title: 'Видеосвязь и интернет',
    color: '#f97350',
    items: [
      { icon: Video, name: 'Система видеоконференц-связи HD' },
      { icon: Wifi, name: 'Wi-Fi 500 Мбит/с' },
      { name: 'Веб-камера 4K' },
      { name: 'Кабель HDMI и адаптеры' }
    ]
  },
  {
    title: 'Мебель и комфорт',
    color: '#24937a',
    items: [
      { name: '40 эргономичных стульев' },
      { name: 'Столы-трансформеры' },
      { name: 'Кафедра для спикера' },
      { name: 'Вешалка для одежды' }
    ]
  },
  {
    title: 'Кофе-брейк зона',
    color: '#f97350',
    items: [
      { icon: Coffee, name: 'Кофемашина профессиональная' },
      { name: 'Чайная станция' },
      { name: 'Кулер с водой' },
      { name: 'Посуда и приборы' }
    ]
  },
  {
    title: 'Дополнительно',
    color: '#24937a',
    items: [
      { icon: Printer, name: 'Принтер/сканер/копир' },
      { name: 'Канцелярские принадлежности' },
      { name: 'Розетки с USB-портами' },
      { name: 'Удлинители и переходники' }
    ]
  }
];

export function Equipment() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#24937a' }}>
            <span className="text-white">Оснащение</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Оснащение конференц-зала
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Всё необходимое оборудование уже включено в стоимость аренды
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {equipmentCategories.map((category, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl p-6 hover:shadow-xl transition-all duration-300"
            >
              <div className="flex items-center gap-3 mb-6">
                <div
                  className="w-1 h-8 rounded"
                  style={{ backgroundColor: category.color }}
                />
                <h3 className="text-xl" style={{ color: category.color }}>
                  {category.title}
                </h3>
              </div>

              <ul className="space-y-3">
                {category.items.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <li key={idx} className="flex items-start gap-3">
                      {Icon ? (
                        <Icon
                          className="w-5 h-5 flex-shrink-0 mt-0.5"
                          style={{ color: category.color }}
                        />
                      ) : (
                        <div
                          className="w-1.5 h-1.5 rounded-full flex-shrink-0 mt-2"
                          style={{ backgroundColor: category.color }}
                        />
                      )}
                      <span className="text-gray-700">{item.name}</span>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </div>

        {/* Note */}
        <div className="mt-12 text-center">
          <div className="inline-block bg-gradient-to-r from-orange-50 to-green-50 rounded-xl px-8 py-4">
            <p className="text-gray-700">
              💡 Все оборудование регулярно проверяется и обслуживается. 
              При необходимости предоставляется техническая поддержка.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
