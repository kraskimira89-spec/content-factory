import { Briefcase, GraduationCap, Users, Presentation, Trophy, PartyPopper, Handshake, Lightbulb } from 'lucide-react';

const eventTypes = [
  {
    icon: Briefcase,
    title: 'Деловые встречи',
    description: 'Переговоры с партнерами, встречи с клиентами, стратегические сессии'
  },
  {
    icon: Presentation,
    title: 'Презентации',
    description: 'Презентации продуктов, услуг, бизнес-планов и проектов'
  },
  {
    icon: GraduationCap,
    title: 'Тренинги и обучение',
    description: 'Корпоративные тренинги, семинары, мастер-классы, воркшопы'
  },
  {
    icon: Users,
    title: 'Конференции',
    description: 'Деловые конференции, форумы, круглые столы, симпозиумы'
  },
  {
    icon: Handshake,
    title: 'Собрания',
    description: 'Собрания акционеров, совещания руководителей, планерки'
  },
  {
    icon: Trophy,
    title: 'Корпоративные мероприятия',
    description: 'Team-building, корпоративы, награждения сотрудников'
  },
  {
    icon: Lightbulb,
    title: 'Мозговые штурмы',
    description: 'Креативные сессии, brainstorming, стратегические планирования'
  },
  {
    icon: PartyPopper,
    title: 'Торжественные события',
    description: 'Юбилеи компании, открытие офисов, пресс-конференции'
  }
];

export function EventTypes() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#24937a' }}>
            <span className="text-white">Мероприятия</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Для каких мероприятий подходит
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Наш конференц-зал — универсальное решение для любых деловых и корпоративных событий
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {eventTypes.map((event, index) => {
            const Icon = event.icon;
            return (
              <div
                key={index}
                className="p-6 rounded-xl border-2 border-gray-100 hover:border-opacity-0 hover:shadow-xl transition-all duration-300 group"
                style={{
                  '--hover-border-color': index % 2 === 0 ? '#f97350' : '#24937a'
                } as React.CSSProperties}
              >
                <div
                  className="w-12 h-12 rounded-lg flex items-center justify-center mb-4 transition-colors"
                  style={{
                    backgroundColor: index % 2 === 0 ? '#f9735015' : '#24937a15'
                  }}
                >
                  <Icon
                    className="w-6 h-6"
                    style={{ color: index % 2 === 0 ? '#f97350' : '#24937a' }}
                  />
                </div>
                <h3 className="text-lg mb-2">{event.title}</h3>
                <p className="text-gray-600 text-sm">{event.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
