import { useState } from 'react';
import { ChevronDown } from 'lucide-react';

const faqs = [
  {
    question: 'Какова минимальная продолжительность аренды?',
    answer: 'Минимальная продолжительность аренды составляет 2 часа. Вы можете арендовать зал почасово или на целый день.'
  },
  {
    question: 'Входит ли оборудование в стоимость аренды?',
    answer: 'Да, всё основное оборудование (проектор, экран, звуковая система, Wi-Fi, флипчарты) включено в стоимость аренды без дополнительной платы.'
  },
  {
    question: 'Можно ли арендовать зал в выходные дни?',
    answer: 'Да, зал доступен для аренды 7 дней в неделю, включая выходные и праздничные дни. Стоимость остается неизменной.'
  },
  {
    question: 'Предоставляете ли вы кофе-брейк?',
    answer: 'В базовую стоимость входит вода и кофе. Полноценные кофе-брейки, обеды и фуршеты организуются дополнительно от 500 ₽ на человека.'
  },
  {
    question: 'Есть ли парковка для участников?',
    answer: 'Да, в бизнес-центре есть подземная парковка для посетителей. Первые 2 часа бесплатно, далее по тарифам парковки.'
  },
  {
    question: 'Можно ли отменить или перенести бронирование?',
    answer: 'Да, вы можете отменить или перенести бронирование не менее чем за 24 часа без штрафных санкций. При отмене менее чем за 24 часа взимается 50% стоимости.'
  },
  {
    question: 'Какие способы оплаты вы принимаете?',
    answer: 'Мы принимаем оплату наличными, банковскими картами и по безналичному расчету с выставлением счета для юридических лиц.'
  },
  {
    question: 'Можно ли провести онлайн-трансляцию мероприятия?',
    answer: 'Да, у нас есть профессиональная система видеоконференц-связи, высокоскоростной интернет и техническая поддержка для онлайн-трансляций.'
  },
  {
    question: 'Предоставляете ли вы техническую поддержку?',
    answer: 'Да, администратор и технический специалист доступны на протяжении всего мероприятия для решения любых технических вопросов.'
  },
  {
    question: 'Можно ли оформить зал в фирменном стиле компании?',
    answer: 'Да, мы предлагаем услугу брендирования зала — установка баннеров, roll-up стендов, оформление в корпоративных цветах от 3 000 ₽.'
  }
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const toggleQuestion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#f97350' }}>
            <span className="text-white">FAQ</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Частые вопросы
          </h2>
          <p className="text-xl text-gray-600">
            Ответы на самые популярные вопросы о нашем конференц-зале
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="bg-white rounded-xl shadow-sm overflow-hidden transition-all duration-300 hover:shadow-md"
            >
              <button
                onClick={() => toggleQuestion(index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left transition-colors"
              >
                <span className="text-lg pr-4">{faq.question}</span>
                <ChevronDown
                  className={`w-6 h-6 flex-shrink-0 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                  style={{ color: index % 2 === 0 ? '#f97350' : '#24937a' }}
                />
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? 'max-h-96' : 'max-h-0'
                }`}
              >
                <div className="px-6 pb-5 text-gray-600">
                  <div
                    className="w-12 h-1 rounded mb-4"
                    style={{ backgroundColor: index % 2 === 0 ? '#f97350' : '#24937a' }}
                  />
                  {faq.answer}
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Contact for more questions */}
        <div className="mt-12 text-center">
          <p className="text-gray-600 mb-4">
            Не нашли ответ на свой вопрос?
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="tel:+74951234567"
              className="px-6 py-3 rounded-lg text-white transition-all duration-300 hover:shadow-lg inline-block"
              style={{ backgroundColor: '#f97350' }}
            >
              Позвонить нам
            </a>
            <button
              onClick={() => document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-6 py-3 rounded-lg border-2 transition-all duration-300 hover:shadow-lg"
              style={{
                borderColor: '#24937a',
                color: '#24937a'
              }}
            >
              Задать вопрос
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
