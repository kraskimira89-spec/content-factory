import { Wifi, Monitor, Coffee, Video, Mic2, AirVent, Shield, Clock } from 'lucide-react';

const features = [
  {
    icon: Monitor,
    title: 'Современное оборудование',
    description: 'Проектор 4K, экран 3м, флипчарты, доски для презентаций'
  },
  {
    icon: Wifi,
    title: 'Высокоскоростной Wi-Fi',
    description: 'Оптоволоконный интернет 500 Мбит/с для всех участников'
  },
  {
    icon: Video,
    title: 'Видеоконференц-связь',
    description: 'Профессиональная система для онлайн-трансляций и встреч'
  },
  {
    icon: Mic2,
    title: 'Звуковое оборудование',
    description: 'Микрофоны, акустическая система, звукоизоляция'
  },
  {
    icon: Coffee,
    title: 'Кофе-брейк зона',
    description: 'Кофемашина, чай, вода, снеки для участников'
  },
  {
    icon: AirVent,
    title: 'Климат-контроль',
    description: 'Современная система кондиционирования и вентиляции'
  },
  {
    icon: Shield,
    title: 'Охрана и безопасность',
    description: 'Видеонаблюдение, контроль доступа, охрана здания'
  },
  {
    icon: Clock,
    title: 'Гибкий график',
    description: 'Почасовая аренда или на целый день по вашему выбору'
  }
];

export function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#24937a' }}>
            <span className="text-white">Преимущества</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Всё необходимое для успешного мероприятия
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Мы создали идеальные условия для продуктивной работы и комфортного общения
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 hover:-translate-y-1"
              >
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-4"
                  style={{ backgroundColor: index % 2 === 0 ? '#f97350' : '#24937a' }}
                >
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="text-xl mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
