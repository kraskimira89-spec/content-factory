import { MapPin, Phone, Mail, Clock } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          {/* About */}
          <div>
            <h3 className="text-2xl mb-4" style={{ color: '#f97350' }}>
              Конференц-Зал
            </h3>
            <p className="text-gray-400 mb-4">
              Премиум пространство для вашего успешного бизнеса в самом центре города
            </p>
            <div className="text-3xl" style={{ color: '#24937a' }}>
              72 м²
            </div>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xl mb-4">Контакты</h4>
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <Phone className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#f97350' }} />
                <div>
                  <a href="tel:+74951234567" className="hover:text-gray-300 transition-colors">
                    +7 (495) 123-45-67
                  </a>
                  <br />
                  <a href="tel:+79991234567" className="hover:text-gray-300 transition-colors">
                    +7 (999) 123-45-67
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-3">
                <Mail className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#f97350' }} />
                <a href="mailto:info@conference-hall.ru" className="hover:text-gray-300 transition-colors">
                  info@conference-hall.ru
                </a>
              </li>
            </ul>
          </div>

          {/* Address */}
          <div>
            <h4 className="text-xl mb-4">Адрес</h4>
            <div className="flex items-start gap-3 mb-4">
              <MapPin className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#f97350' }} />
              <div className="text-gray-400">
                г. Ноябрьск, ЯНАО<br />
                ул. Ленина, д. 55<br />
                Бизнес-центр "Премиум"
              </div>
            </div>
            <a
              href="#"
              className="inline-block px-4 py-2 rounded-lg border border-gray-600 hover:border-gray-400 transition-colors"
            >
              Показать на карте
            </a>
          </div>

          {/* Hours */}
          <div>
            <h4 className="text-xl mb-4">Режим работы</h4>
            <div className="flex items-start gap-3 mb-4">
              <Clock className="w-5 h-5 mt-1 flex-shrink-0" style={{ color: '#f97350' }} />
              <div className="text-gray-400">
                <div className="mb-2">Понедельник - Пятница:<br />8:00 - 22:00</div>
                <div className="mb-2">Суббота - Воскресенье:<br />9:00 - 20:00</div>
                <div className="text-sm" style={{ color: '#24937a' }}>
                  * Аренда 24/7 по договоренности
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-800 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-sm">
              © 2026 Конференц-Зал. Все права защищены.
            </p>
            <div className="flex gap-6 text-sm text-gray-400">
              <a href="#" className="hover:text-white transition-colors">
                Политика конфиденциальности
              </a>
              <a href="#" className="hover:text-white transition-colors">
                Условия использования
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}