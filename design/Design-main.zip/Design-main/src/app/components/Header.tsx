import { useState, useEffect } from 'react';
import { Menu, X, Phone } from 'lucide-react';

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setIsMobileMenuOpen(false);
  };

  const menuItems = [
    { label: 'Главная', id: 'hero' },
    { label: 'Преимущества', id: 'features' },
    { label: 'Тарифы', id: 'pricing' },
    { label: 'Бронирование', id: 'booking' }
  ];

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled ? 'bg-white shadow-lg' : 'bg-white/10 backdrop-blur-md'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Logo */}
          <div className="flex items-center">
            <button
              onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
              className={`text-2xl transition-colors ${
                isScrolled ? 'text-gray-900' : 'text-white'
              }`}
              style={isScrolled ? { color: '#f97350' } : {}}
            >
              Конференц-Зал
            </button>
            <div
              className={`ml-3 px-2 py-1 rounded text-sm ${
                isScrolled ? 'bg-gray-100' : 'bg-white/20'
              }`}
              style={isScrolled ? { color: '#24937a' } : { color: 'white' }}
            >
              72 м²
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-8">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className={`transition-colors hover:opacity-80 ${
                  isScrolled ? 'text-gray-700' : 'text-white'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          {/* Phone & CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="tel:+74951234567"
              className={`flex items-center gap-2 transition-colors ${
                isScrolled ? 'text-gray-700' : 'text-white'
              }`}
            >
              <Phone className="w-5 h-5" />
              +7 (495) 123-45-67
            </a>
            <button
              onClick={() => scrollToSection('booking')}
              className="px-6 py-2 rounded-lg text-white transition-all duration-300 hover:shadow-lg hover:scale-105"
              style={{ backgroundColor: '#f97350' }}
            >
              Забронировать
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className={`md:hidden transition-colors ${
              isScrolled ? 'text-gray-900' : 'text-white'
            }`}
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t">
          <nav className="px-4 py-6 space-y-4">
            {menuItems.map((item) => (
              <button
                key={item.id}
                onClick={() => scrollToSection(item.id)}
                className="block w-full text-left py-2 text-gray-700 hover:text-gray-900"
              >
                {item.label}
              </button>
            ))}
            <a
              href="tel:+74951234567"
              className="flex items-center gap-2 py-2 text-gray-700"
            >
              <Phone className="w-5 h-5" />
              +7 (495) 123-45-67
            </a>
            <button
              onClick={() => scrollToSection('booking')}
              className="w-full px-6 py-3 rounded-lg text-white"
              style={{ backgroundColor: '#f97350' }}
            >
              Забронировать
            </button>
          </nav>
        </div>
      )}
    </header>
  );
}
