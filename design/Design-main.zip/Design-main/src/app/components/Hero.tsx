import { ImageWithFallback } from './figma/ImageWithFallback';
import { Calendar, Users, ArrowRight } from 'lucide-react';

export function Hero() {
  const scrollToBooking = () => {
    document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1687945727613-a4d06cc41024?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBjb25mZXJlbmNlJTIwcm9vbSUyMG1lZXRpbmd8ZW58MXx8fHwxNzczMTI2OTc1fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Конференц-зал"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-black/50"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
        <div className="max-w-3xl">
          <div className="inline-block px-4 py-2 rounded-full mb-6" style={{ backgroundColor: '#f97350' }}>
            <span className="text-white">72 кв.м профессионального пространства</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl text-white mb-6">
            Конференц-зал премиум класса в Ноябрьске
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-200 mb-8">
            Идеальное место для проведения встреч, презентаций, тренингов и корпоративных мероприятий
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <button
              onClick={scrollToBooking}
              className="px-8 py-4 rounded-lg text-white transition-all duration-300 hover:shadow-lg hover:scale-105 flex items-center justify-center gap-2"
              style={{ backgroundColor: '#f97350' }}
            >
              Забронировать сейчас
              <ArrowRight className="w-5 h-5" />
            </button>
            
            <button
              onClick={() => document.getElementById('features')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 rounded-lg bg-white/10 backdrop-blur-sm text-white border-2 border-white/30 transition-all duration-300 hover:bg-white/20"
            >
              Узнать больше
            </button>
          </div>

          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#24937a' }}>
                <Users className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl text-white">до 50</div>
                <div className="text-sm text-gray-300">человек</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#24937a' }}>
                <Calendar className="w-6 h-6 text-white" />
              </div>
              <div>
                <div className="text-2xl text-white">24/7</div>
                <div className="text-sm text-gray-300">доступность</div>
              </div>
            </div>
            
            <div className="flex items-center gap-3 col-span-2 md:col-span-1">
              <div className="w-12 h-12 rounded-full flex items-center justify-center" style={{ backgroundColor: '#24937a' }}>
                <svg className="w-6 h-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
              </div>
              <div>
                <div className="text-2xl text-white">72 м²</div>
                <div className="text-sm text-gray-300">площадь</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-2 bg-white/50 rounded-full"></div>
        </div>
      </div>
    </section>
  );
}