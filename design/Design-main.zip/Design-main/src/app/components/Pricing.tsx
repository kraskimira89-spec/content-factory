import { Check } from 'lucide-react';

const plans = [
  {
    name: 'Почасовая аренда',
    price: '2 500',
    period: 'час',
    description: 'Идеально для коротких встреч и презентаций',
    features: [
      'Минимум 2 часа',
      'Все оборудование включено',
      'Wi-Fi и видеосвязь',
      'Кофе и вода',
      'Поддержка администратора'
    ],
    color: '#f97350'
  },
  {
    name: 'Полный день',
    price: '15 000',
    period: 'день',
    description: 'Оптимальный вариант для тренингов и семинаров',
    features: [
      'До 10 часов использования',
      'Все оборудование включено',
      'Wi-Fi и видеосвязь',
      'Кофе-брейки (3 раза)',
      'Поддержка администратора',
      'Помощь в организации обеда'
    ],
    popular: true,
    color: '#24937a'
  },
  {
    name: 'Абонемент',
    price: '60 000',
    period: 'месяц',
    description: 'Выгодно для регулярного использования',
    features: [
      '20 дней в месяц',
      'Все оборудование включено',
      'Wi-Fi и видеосвязь',
      'Безлимитные кофе-брейки',
      'Персональный менеджер',
      'Приоритетное бронирование',
      'Скидка 25%'
    ],
    color: '#f97350'
  }
];

export function Pricing() {
  const scrollToBooking = () => {
    document.getElementById('booking')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#24937a' }}>
            <span className="text-white">Тарифы</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Прозрачные цены
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Выберите оптимальный вариант для вашего мероприятия
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`bg-white rounded-2xl shadow-lg p-8 relative ${
                plan.popular ? 'ring-4 scale-105 z-10' : ''
              }`}
              style={plan.popular ? { ringColor: plan.color } : {}}
            >
              {plan.popular && (
                <div
                  className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-white text-sm"
                  style={{ backgroundColor: plan.color }}
                >
                  Популярный
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-2xl mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-6">{plan.description}</p>
                <div className="flex items-baseline justify-center gap-2">
                  <span className="text-5xl" style={{ color: plan.color }}>
                    {plan.price}
                  </span>
                  <span className="text-gray-600">₽</span>
                </div>
                <div className="text-gray-500 mt-1">за {plan.period}</div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <div
                      className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ backgroundColor: plan.color }}
                    >
                      <Check className="w-3 h-3 text-white" />
                    </div>
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <button
                onClick={scrollToBooking}
                className={`w-full py-3 rounded-lg text-white transition-all duration-300 hover:shadow-lg hover:scale-105`}
                style={{ backgroundColor: plan.color }}
              >
                Забронировать
              </button>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-gray-600">
            * Все цены указаны с НДС. Возможна оплата по безналичному расчету.
          </p>
        </div>
      </div>
    </section>
  );
}
