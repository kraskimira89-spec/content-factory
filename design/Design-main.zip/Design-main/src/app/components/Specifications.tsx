import { Maximize2, Users, Armchair, Layout, Lightbulb, Wind } from 'lucide-react';

const specs = [
  {
    icon: Maximize2,
    label: 'Площадь',
    value: '72 м²',
    color: '#f97350'
  },
  {
    icon: Users,
    label: 'Вместимость',
    value: 'до 50 человек',
    color: '#24937a'
  },
  {
    icon: Armchair,
    label: 'Посадочные места',
    value: '40 стульев',
    color: '#f97350'
  },
  {
    icon: Layout,
    label: 'Планировка',
    value: 'трансформируемая',
    color: '#24937a'
  },
  {
    icon: Lightbulb,
    label: 'Освещение',
    value: 'регулируемое LED',
    color: '#f97350'
  },
  {
    icon: Wind,
    label: 'Вентиляция',
    value: 'принудительная',
    color: '#24937a'
  }
];

const additionalInfo = [
  'Высота потолков: 3.2 метра',
  'Естественное освещение: панорамные окна',
  'Звукоизоляция: профессиональная',
  'Напольное покрытие: ламинат премиум-класса',
  'Раздельные санузлы на этаже',
  'Гардероб для верхней одежды'
];

export function Specifications() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#f97350' }}>
            <span className="text-white">Характеристики</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Характеристики зала
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Технические параметры и особенности пространства
          </p>
        </div>

        {/* Main Specs Grid */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-12">
          {specs.map((spec, index) => {
            const Icon = spec.icon;
            return (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-sm text-center hover:shadow-lg transition-all duration-300"
              >
                <div
                  className="w-14 h-14 rounded-full flex items-center justify-center mx-auto mb-3"
                  style={{ backgroundColor: spec.color + '20' }}
                >
                  <Icon className="w-7 h-7" style={{ color: spec.color }} />
                </div>
                <div className="text-sm text-gray-600 mb-1">{spec.label}</div>
                <div className="text-lg" style={{ color: spec.color }}>
                  {spec.value}
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Information */}
        <div className="bg-white rounded-2xl shadow-lg p-8 md:p-12">
          <h3 className="text-2xl mb-6 text-center" style={{ color: '#24937a' }}>
            Дополнительная информация
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {additionalInfo.map((info, index) => (
              <div key={index} className="flex items-center gap-3">
                <div
                  className="w-2 h-2 rounded-full flex-shrink-0"
                  style={{ backgroundColor: index % 2 === 0 ? '#f97350' : '#24937a' }}
                />
                <span className="text-gray-700">{info}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
