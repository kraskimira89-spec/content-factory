import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Анна Смирнова',
    position: 'Директор по развитию, ООО "Инновации"',
    text: 'Проводили корпоративный тренинг на 35 человек. Зал идеально подошел — современное оборудование, удобная мебель, отличная акустика. Администратор помог со всеми организационными вопросами. Обязательно вернемся!',
    rating: 5
  },
  {
    name: 'Дмитрий Кузнецов',
    position: 'Руководитель отдела продаж, "ТехноПро"',
    text: 'Регулярно снимаем зал для презентаций новых продуктов клиентам. Всё на высшем уровне — проектор отличного качества, быстрый интернет, удобное расположение. Клиенты всегда довольны!',
    rating: 5
  },
  {
    name: 'Елена Волкова',
    position: 'Организатор мероприятий',
    text: 'Организовывала бизнес-конференцию на 50 участников. Зал просторный, хорошая звукоизоляция, профессиональное оборудование. Отдельное спасибо за помощь с кофе-брейками и техподдержкой!',
    rating: 5
  },
  {
    name: 'Игорь Петров',
    position: 'CEO, StartupHub',
    text: 'Использовали зал для питч-сессии стартапов. Идеальное место — современный интерьер, всё необходимое оборудование, гибкие условия аренды. Рекомендую всем!',
    rating: 5
  }
];

export function Testimonials() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 rounded-full mb-4" style={{ backgroundColor: '#24937a' }}>
            <span className="text-white">Отзывы</span>
          </div>
          <h2 className="text-4xl md:text-5xl mb-4">
            Отзывы организаторов
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Более 200 успешных мероприятий — наши клиенты рекомендуют нас
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="bg-gray-50 rounded-2xl p-8 relative hover:shadow-xl transition-all duration-300"
            >
              {/* Quote Icon */}
              <div className="absolute top-6 right-6 opacity-10">
                <Quote className="w-16 h-16" style={{ color: index % 2 === 0 ? '#f97350' : '#24937a' }} />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="w-5 h-5 fill-current"
                    style={{ color: '#f97350' }}
                  />
                ))}
              </div>

              {/* Text */}
              <p className="text-gray-700 mb-6 relative z-10 italic">
                "{testimonial.text}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div
                  className="w-12 h-12 rounded-full flex items-center justify-center text-white text-xl"
                  style={{ backgroundColor: index % 2 === 0 ? '#f97350' : '#24937a' }}
                >
                  {testimonial.name.charAt(0)}
                </div>
                <div>
                  <div className="font-medium text-gray-900">{testimonial.name}</div>
                  <div className="text-sm text-gray-600">{testimonial.position}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-16 max-w-4xl mx-auto">
          <div className="text-center">
            <div className="text-4xl mb-2" style={{ color: '#f97350' }}>
              200+
            </div>
            <div className="text-gray-600">Мероприятий</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2" style={{ color: '#24937a' }}>
              98%
            </div>
            <div className="text-gray-600">Довольных клиентов</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2" style={{ color: '#f97350' }}>
              150+
            </div>
            <div className="text-gray-600">Компаний</div>
          </div>
          <div className="text-center">
            <div className="text-4xl mb-2" style={{ color: '#24937a' }}>
              5.0
            </div>
            <div className="text-gray-600">Средний рейтинг</div>
          </div>
        </div>
      </div>
    </section>
  );
}
